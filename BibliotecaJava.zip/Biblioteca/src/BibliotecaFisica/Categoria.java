package BibliotecaFisica;

public enum Categoria {
	SUSPENSE, 
	TERROR, 
	POESIA, 
	CRONICA, 
	ROMANCE, 
	CONTO, 
	FICCAO, 
	FANTASIA

}
